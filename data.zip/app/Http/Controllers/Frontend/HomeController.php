<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Model\About\About;
use App\Model\Service\Service;
use App\Model\Slider\Slider;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function home()
    {
        $sliders = Slider::where('status',1)->get();
        $services = Service::where('status',1)->get();
        $about = About::get();
        if(count($about)>0){
            $about = $about->first();
        }else{
            $about = [];
        }
        return view('frontend.home', compact('sliders', 'about', 'services'));
    }
}
