<?php

namespace App\Model\About;

use Illuminate\Database\Eloquent\Model;

class About extends Model
{

}
