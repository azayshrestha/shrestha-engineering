@extends('backend.includes.layout')

@section('title')
    About Us
@stop

@section('formHeader')
    About Us
@stop

@section('formSubHeader')

@stop

@section('style')

@stop

@section('script')

@stop

@section('content')
    <a href="" class="btn btn-info" data-toggle="modal" data-target="#addContent">
        @if(!$about) Add @else Update @endif About Us
    </a>
    <hr>
    <div class="card">
        <div class="card-body">
            @if($about)
                {!! $about->content !!}
            @endif
        </div>
    </div>

    <!-- The Modal -->
    <div class="modal" id="addContent">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Add About</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                @if($about)
                    <form method="post" action="{{route('about.update', $about->id)}}" enctype="multipart/form-data">
                    <input type="hidden" name="_method" value="PUT">
                @else
                    <form method="post" action="{{route('about.store')}}" enctype="multipart/form-data">
                @endif

                {{@csrf_field()}}
                <!-- Modal body -->
                    <div class="modal-body">
                        <div class="row">
                            @if($about)
                                <textarea class="textarea w-100" name="about_content">{{$about->content}}</textarea>
                            @else
                                <textarea class="textarea w-100" name="about_content">{{old('about_content')}}</textarea>
                            @endif
                        </div>
                    </div>
                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-outline-info">
                            @if(!$about) Submit @else Update @endif
                        </button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


@stop