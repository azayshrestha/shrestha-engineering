@include('frontend.includes.header')
    @yield('content')
@include('frontend.includes.footer')