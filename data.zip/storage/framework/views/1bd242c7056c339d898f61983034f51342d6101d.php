




    
    
    
    
    
    
    
    
    
    

    
    
    
    
    






    
    

    
        
        
            
                
                    
                

                
                
                    
                    
                        
                            
                            
                                
                            
                        

                        
                            
                                

                                
                                

                                
                                

                                
                                

                                

                                
                            
                        
                    
                    
                
            
        
        

        
        
            
            

            
                
                
                
                
                    
                        
                        
                        
                        
                        
                    
                
            
        

    
    

<!DOCTYPE html>
<html lang="en">

<!-- stella-orre/index-2.html  30 Nov 2019 03:46:47 GMT -->
<head>
    <meta charset="utf-8">
    <title></title>
    <!-- Stylesheets -->
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">

    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

</head>

<body class="dark-layout">

<div class="page-wrapper">
    <!-- Preloader -->
    

    <!-- Main Header / Header Style Two -->
    <header class="main-header header-style-two">

        <!-- Header Upper -->
        <div class="header-upper">
            <div class="outer-container clearfix">
                <!--Info-->
                <div class="logo-outer">
                    
                </div>

                <!--Nav Box-->
                <div class="nav-outer clearfix">
                    <!--Mobile Navigation Toggler For Mobile--><div class="mobile-nav-toggler"><span class="icon flaticon-menu-1"></span></div>
                    <nav class="main-menu navbar-expand-md navbar-light">
                        <div class="navbar-header">
                            <!-- Togg le Button -->
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon flaticon-menu-1"></span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix">
                                <li class="current dropdown"><a href="index-2.html">Home</a>
                                </li>
                                <li class="dropdown"><a href="about.html">About us</a>

                                </li>
                                <li class="dropdown"><a href="services-dark.html">Services</a>

                                </li>
                                <li class="dropdown"><a href="projects-classic.html">Projects</a>

                                </li>

                                <li><a href="contact.html">Contact</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>

        </div>
        <!--End Header Upper-->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><span class="icon flaticon-cancel"></span></div>

            <nav class="menu-box">
                <div class="nav-logo"><a href="index-2.html"><img src="images/logo.png" alt="" title=""></a></div>
                <ul class="navigation clearfix"><!--Keep This Empty / Menu will come through Javascript--></ul>
                <!--Social Links-->
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="#"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->

    </header>
    <!-- End Main Header --><?php /**PATH D:\Laravel Projects\engineering-firm\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>