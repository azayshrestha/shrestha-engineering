

<?php $__env->startSection('title'); ?>
    Services
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formHeader'); ?>
    <?php if(!$service): ?> Add <?php else: ?> Update <?php endif; ?> Services
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formSubHeader'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-6 offset-3">
        <div class="card">
            <div class="card-body">
                <?php if(!$service): ?>
                <form method="post" action="<?php echo e(route('service.store')); ?>" enctype="multipart/form-data">
                <?php else: ?>
                <form method="post" action="<?php echo e(route('service.update', $service->id)); ?>" enctype="multipart/form-data">
                    <input type="hidden" name="_method" value="PUT">
                <?php endif; ?>
                    <?php echo e(@csrf_field()); ?>

                    <div class="form-group">
                        <label>Service Title <span class="text-red">*</span></label>
                        <input type="text" name="title" class="form-control <?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>"
                               value="<?php if(!$service): ?> <?php echo e(old('title')); ?> <?php else: ?> <?php echo e($service->title); ?> <?php endif; ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('title')); ?></strong>
                    </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>Short Description <span class="text-red">*</span></label>
                        <textarea class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" required><?php if(!$service): ?> <?php echo e(old('description')); ?> <?php else: ?> <?php echo e($service->description); ?> <?php endif; ?></textarea>
                        <?php if($errors->has('description')): ?>
                            <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('description')); ?></strong>
                    </span>
                        <?php endif; ?>
                    </div>
                    <?php if($service): ?>
                        <?php if($service->image): ?>
                            <img class="rounded card elevation-3"  height="140px" src="<?php echo e(asset('images/serviceImage/'.$service->image)); ?>">
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Image <span class="text-red">*</span></label>
                        <input type="file" name="image" class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('image')); ?>" <?php if(!$service): ?> required <?php endif; ?>>
                        <?php if($errors->has('image')): ?>
                            <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('image')); ?></strong>
                    </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>Service Content</label>
                        <textarea class="textarea" name="service_content"><?php if(!$service): ?><?php echo e(old('service_content')); ?><?php else: ?><?php echo $service->content; ?><?php endif; ?></textarea>
                        <?php if($errors->has('content')): ?>
                            <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('content')); ?></strong>
                    </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Status <span class="red">*</span></label> <br>
                        <label><input type="radio" name="status" value="1" class="mr-2"
                         <?php if(!$service): ?>
                            checked
                         <?php else: ?>
                            <?php if($service->status == 1): ?> checked <?php endif; ?>
                          <?php endif; ?> required> Active</label>
                        <label class="ml-3"><input type="radio" name="status" value="0" class="mr-2"  <?php if($service && $service->status == 0): ?> checked <?php endif; ?> required> In-Active</label>
                    </div>

                    <button type="submit" class="btn btn-outline-info"><?php if(!$service): ?> Add <?php else: ?> Update <?php endif; ?> Service</button>

                </form>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Projects\engineering-firm\resources\views/backend/service/add.blade.php ENDPATH**/ ?>