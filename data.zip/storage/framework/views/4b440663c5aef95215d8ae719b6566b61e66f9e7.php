

<?php $__env->startSection('title'); ?>
    Manage Services
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formHeader'); ?>
    Manage Services
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formSubHeader'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('service.create')); ?>" class="btn btn-info">Add Services</a>
    <hr>
    <div class="card">
        <div class="card-body">
            <table class="table dtable" width="100%">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Service Title</th>
                    <th width="40%">Short Description</th>
                    <th>status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>

                        <td><?php echo e($service->title); ?></td>
                        <td><?php echo e($service->description); ?></td>
                        <td>
                            <?php if($service->status == 1): ?>
                                <span class="badge badge-success">Active</span>
                            <?php elseif($service->status ==0): ?>
                                <span class="badge badge-danger">In-Active</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('service.edit', $service->id)); ?>" class="btn btn-primary" title="Edit Slider"><i class="fa fa-edit"></i></a>
                            <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($service->id); ?>" title="Delete Image"><i class="fa fa-trash"></i></a>
                        </td>

                        <!-- The Modal -->
                        <div class="modal" id="delete<?php echo e($service->id); ?>">
                            <div class="modal-dialog modal-sm">
                                <div class="modal-content">
                                    <form method="post" action="<?php echo e(route('service.destroy', $service->id)); ?>">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo e(@csrf_field()); ?>

                                        <div class="modal-header">
                                            <h5 class="modal-title"><i class="fa fa-trash-o"></i> Delete Confirmation!</h5>
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            Are you sure to remove this record?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                            <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Projects\engineering-firm\resources\views/backend/service/index.blade.php ENDPATH**/ ?>