

<?php $__env->startSection('title'); ?>
    Manage Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formHeader'); ?>
    Manage Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formSubHeader'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="" class="btn btn-info" data-toggle="modal" data-target="#addUser">Add User</a>
    <hr>
    <div class="card">
        <div class="card-body">
        <table class="table dtable" width="100%">
            <thead>
            <tr>
                <th>#</th>
                <th>User Name</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>

                    <td>
                        <a href="#editUser" class="btn btn-primary" data-toggle="modal" title="Edit User" data-target="#editUser<?php echo e($user->id); ?>"><i class="fa fa-edit"></i></a>
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($user->id); ?>" title="Delete User"><i class="fa fa-trash"></i></a>
                    </td>

                    <div class="modal" id="delete<?php echo e($user->id); ?>">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <form method="post" action="<?php echo e(route('user.destroy', $user->id)); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo e(@csrf_field()); ?>

                                    <div class="modal-header">
                                        <h5 class="modal-title"><i class="fa fa-trash-o"></i> Delete Confirmation!</h5>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        Are you sure to remove this record?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- The Modal -->
    <div class="modal" id="addUser">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Add User</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="post" action="<?php echo e(route('user.store')); ?>" enctype="multipart/form-data">
                <?php echo e(@csrf_field()); ?>

                <!-- Modal body -->
                    <div class="modal-body">

                            <div class="row">
                                <div class="col-6 form-group">
                                    <label>First Name</label>
                                    <input type="text" name="first_name" class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('first_name')); ?>" required>
                                    <?php if($errors->has('first_name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-6 form-group">
                                    <label>Last Name</label>
                                    <input type="text" name="last_name" class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('last_name')); ?>" required>
                                    <?php if($errors->has('last_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-12 form-group">
                                    <label>Email</label>
                                    <input type="text" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" required>
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-6 form-group">
                                    <label>Password</label>
                                    <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('password')); ?>" required>
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-6 form-group">
                                    <label>Confirm Password</label>
                                    <input type="password" name="password_confirmation" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('password_confirmation')); ?>" required>
                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                    </div>
                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-outline-info">Submit</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal" id="editUser<?php echo e($user->id); ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Edit User</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form method="post" action="<?php echo e(route('user.update', $user->id)); ?>" enctype="multipart/form-data">
                        <input type="hidden" name="_method" value="PUT">
                    <?php echo e(@csrf_field()); ?>

                    <!-- Modal body -->
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-6 form-group">
                                    <label>First Name</label>
                                    <input type="text" name="first_name" class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" value="<?php echo e($user->first_name); ?>" required>
                                    <?php if($errors->has('first_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-6 form-group">
                                    <label>Last Name</label>
                                    <input type="text" name="last_name" class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" value="<?php echo e($user->last_name); ?>" required>
                                    <?php if($errors->has('last_name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-12 form-group">
                                    <label>Email</label>
                                    <input type="text" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e($user->email); ?>" required>
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-6 form-group">
                                    <label>Password</label>
                                    <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('password')); ?>">
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-6 form-group">
                                    <label>Confirm Password</label>
                                    <input type="password" name="password_confirmation" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('password_confirmation')); ?>">
                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <small class="pl-3">* If you dnt want to change password, leave Password Field Blank.</small>
                            </div>
                        </div>
                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-outline-info">Update</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Projects\engineering-firm\resources\views/backend/users/index.blade.php ENDPATH**/ ?>