<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="" class="brand-link">
        <span class="brand-text font-weight-light pl-3">AdminPanel</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(Sentinel::check()->first_name); ?> <?php echo e(Sentinel::check()->last_name); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column nav-legacy nav-flat nav-child-indent text-sm" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="/" class="nav-link">
                        <i class="nav-icon fas fa-meteor"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('user.index')); ?>" class="nav-link <?php echo e(Request::is('admin/user') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-user-cog"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('slider.index')); ?>" class="nav-link <?php echo e(Request::is('admin/slider') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-images"></i>
                        <p>Image Slider</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('about.index')); ?>" class="nav-link <?php echo e(Request::is('admin/about') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-info-circle"></i>
                        <p>About Us</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-users"></i>
                        <p>Our Team</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('service.index')); ?>" class="nav-link <?php echo e(Request::is('admin/service*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-hammer"></i>
                        <p>Our Services</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-quote-left"></i>
                        <p>Testimonials</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-phone"></i>
                        <p>Contact Info</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-briefcase"></i>
                        <p>Manage Portfolio</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-question"></i>
                        <p>
                            Manage Queries
                            <span class="right badge badge-danger">4</span>
                        </p>
                    </a>
                </li>

                <hr>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>
                            Sign Out
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH D:\Laravel Projects\engineering-firm\resources\views/backend/includes/sidebar.blade.php ENDPATH**/ ?>