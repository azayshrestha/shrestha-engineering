

<?php $__env->startSection('title'); ?>
    Shrestha Engineering Inc.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($sliders): ?>
    <!-- Main Slider -->
    <section class="main-slider style-two">
        <div class="slider-box">
            <!-- Banner Carousel -->
            <div class="banner-carousel owl-theme owl-carousel">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Slide -->
                    <div class="slide">
                        <div class="image-layer" style="background-image:url(<?php echo e(asset('images/sliderImage/'.$slider->image)); ?>)">

                        </div>
                        <div class="auto-container">
                            <div class="content">
                                <h2><?php echo e($slider->title); ?></h2>
                                <div class="text"><?php echo e($slider->description); ?></div>
                                <?php if($slider->url): ?>
                                    <div class="btns-box">
                                        <a href="<?php echo e($slider->url); ?>" class="theme-btn btn-style-one"><span class="txt">Know more</span></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- Social Icons -->
            <ul class="social-icons">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-linkedin-in"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-google-plus-g"></span></a></li>
            </ul>
        </div>
    </section>
    <!-- End Banner Section -->
<?php endif; ?>


<?php if($about): ?>
<!-- About Section -->
<section class="about-section" style="background-color: #1A1A1A">
    <div class="auto-container">
        <div class="row no-gutters">
            <div class="image-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column">
                    <div class="image-box">

                        <figure class="image wow fadeInRight" data-wow-delay='600ms'>
                            <img src="<?php echo e(asset('images/gallery/9.jpg')); ?>" alt="">
                        </figure>
                    </div>
                </div>
            </div>

            <div class="content-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column wow fadeInLeft">
                    <div class="content-box">
                        <div class="title">
                            <div class="title-box wow fadeInLeft" data-wow-delay='1200ms'>
                                <h2>ABOUT US</h2>
                            </div>
                        </div>
                        <div class="text">
                            <?php echo e(substr(strip_tags($about->content),0, 320)); ?>

                        </div>
                        <div class="link-box"><a href="about.html" class="theme-btn btn-style-one">About Us</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End About Section -->
<?php endif; ?>


<?php if($services): ?>
<!-- Services Section -->
<section class="services-section">
    <div class="auto-container">
        <!-- Title Box -->
        <div class="title-box">
            <h2>Our Services</h2>
        </div>
        <div class="row clearfix">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="service-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <div class="image">
                        <a href="residental-interior.html"><img src="<?php echo e(asset('images/serviceImage/'.$service->image)); ?>" alt="" /></a>
                    </div>
                    <div class="lower-content">
                        <h3><a href="residental-interior.html"><?php echo e($service->title); ?></a></h3>
                        <div class="text"><?php echo e(substr($service->description, 0,100)); ?>..</div>
                        <a href="residental-interior.html" class="read-more">Read more</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- End Services Section -->
<?php endif; ?>

<!-- Project Section -->
<section class="projects-section">
    <div class="auto-container">
        <div class="sec-title text-right">
            <h2>Our Project</h2>
        </div>
    </div>

    <div class="inner-container">
        <div class="projects-carousel owl-carousel owl-theme">
            <!-- Project Block -->
            <div class="project-block">
                <div class="image-box">
                    <figure class="image"><img src="images/gallery/1.jpg" alt=""></figure>
                    <div class="overlay-box">
                        <h4><a href="project-detail.html">Laxury Home <br>Project</a></h4>
                        <div class="btn-box">
                            <a href="images/gallery/1.jpg" class="lightbox-image" data-fancybox="gallery"><i class="fa fa-search"></i></a>
                            <a href="project-detail.html"><i class="fa fa-external-link"></i></a>
                        </div>
                        <span class="tag">Architecture</span>
                    </div>
                </div>
            </div>

            <!-- Project Block -->
            <div class="project-block">
                <div class="image-box">
                    <figure class="image"><img src="images/gallery/2.jpg" alt=""></figure>
                    <div class="overlay-box">
                        <h4><a href="project-detail.html">Laxury Home <br>Project</a></h4>
                        <div class="btn-box">
                            <a href="images/gallery/2.jpg" class="lightbox-image" data-fancybox="gallery"><i class="fa fa-search"></i></a>
                            <a href="project-detail.html"><i class="fa fa-external-link"></i></a>
                        </div>
                        <span class="tag">Architecture</span>
                    </div>
                </div>
            </div>

            <!-- Project Block -->
            <div class="project-block">
                <div class="image-box">
                    <figure class="image"><img src="images/gallery/3.jpg" alt=""></figure>
                    <div class="overlay-box">
                        <h4><a href="project-detail.html">Laxury Home <br>Project</a></h4>
                        <div class="btn-box">
                            <a href="images/gallery/3.jpg" class="lightbox-image" data-fancybox="gallery"><i class="fa fa-search"></i></a>
                            <a href="project-detail.html"><i class="fa fa-external-link"></i></a>
                        </div>
                        <span class="tag">Architecture</span>
                    </div>
                </div>
            </div>

            <!-- Project Block -->
            <div class="project-block">
                <div class="image-box">
                    <figure class="image"><img src="images/gallery/4.jpg" alt=""></figure>
                    <div class="overlay-box">
                        <h4><a href="project-detail.html">Laxury Home <br>Project</a></h4>
                        <div class="btn-box">
                            <a href="images/gallery/4.jpg" class="lightbox-image" data-fancybox="gallery"><i class="fa fa-search"></i></a>
                            <a href="project-detail.html"><i class="fa fa-external-link"></i></a>
                        </div>
                        <span class="tag">Architecture</span>
                    </div>
                </div>
            </div>

            <!-- Project Block -->
            <div class="project-block">
                <div class="image-box">
                    <figure class="image"><img src="images/gallery/5.jpg" alt=""></figure>
                    <div class="overlay-box">
                        <h4><a href="project-detail.html">Laxury Home <br>Project</a></h4>
                        <div class="btn-box">
                            <a href="images/gallery/5.jpg" class="lightbox-image" data-fancybox="gallery"><i class="fa fa-search"></i></a>
                            <a href="project-detail.html"><i class="fa fa-external-link"></i></a>
                        </div>
                        <span class="tag">Architecture</span>
                    </div>
                </div>
            </div>

            <!-- Project Block -->
            <div class="project-block">
                <div class="image-box">
                    <figure class="image"><img src="images/gallery/3.jpg" alt=""></figure>
                    <div class="overlay-box">
                        <h4><a href="project-detail.html">Laxury Home <br>Project</a></h4>
                        <div class="btn-box">
                            <a href="images/gallery/3.jpg" class="lightbox-image" data-fancybox="gallery"><i class="fa fa-search"></i></a>
                            <a href="project-detail.html"><i class="fa fa-external-link"></i></a>
                        </div>
                        <span class="tag">Architecture</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Project Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Projects\engineering-firm\resources\views/frontend/home.blade.php ENDPATH**/ ?>