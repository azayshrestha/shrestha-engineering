

<?php $__env->startSection('title'); ?>
    Manage Image Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formHeader'); ?>
    Manage Image Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('formSubHeader'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <a href="" class="btn btn-info" data-toggle="modal" data-target="#addSlider">Add Image Slider</a>
        <hr>
    <div class="card">
        <div class="card-body">
        <table class="table dtable" width="100%">
            <thead>
            <tr>
                <th>#</th>
                <th>Slider Image</th>
                <th>Title</th>
                <th>status</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td>
                        <a href="<?php echo e(asset('images/sliderImage/'.$slider->image)); ?>" data-lightbox="<?php echo e($slider->slider_id); ?>">
                            <img src="<?php echo e(asset('images/sliderImage/'.$slider->image)); ?>" style="height: 50px;">
                        </a>
                    </td>
                    <td><?php echo e($slider->title); ?></td>
                    <td>
                        <?php if($slider->status == 1): ?>
                            <span class="badge badge-success">Active</span>
                        <?php elseif($slider->status ==0): ?>
                            <span class="badge badge-danger">In-Active</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="#editSlider" class="btn btn-primary" data-toggle="modal" title="Edit Slider" data-target="#editSlider<?php echo e($slider->slider_id); ?>"><i class="fa fa-edit"></i></a>
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($slider->slider_id); ?>" title="Delete Image"><i class="fa fa-trash"></i></a>
                    </td>

                    <!-- The Modal -->
                    <div class="modal" id="delete<?php echo e($slider->slider_id); ?>">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <form method="post" action="<?php echo e(route('slider.destroy', $slider->id)); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo e(@csrf_field()); ?>

                                <!-- Modal Header -->
                                    <div class="modal-header">
                                        <h5 class="modal-title"><i class="fa fa-trash-o"></i> Delete Confirmation!</h5>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        Are you sure to remove this record?
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>

    <!-- The Modal -->
    <div class="modal" id="addSlider">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Add Images in Slider</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="post" action="<?php echo e(route('slider.store')); ?>" enctype="multipart/form-data">
                <?php echo e(@csrf_field()); ?>

                <!-- Modal body -->
                    <div class="modal-body">
                        <div class="form-group">
                        <label>Image Title</label>
                        <input type="text" name="title" class="form-control <?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('title')); ?>">
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                        <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <input type="text" name="description" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('description')); ?>">
                            <?php if($errors->has('description')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Image <span class="red">*</span></label>
                            <input type="file" name="image" class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('image')); ?>" required>
                            <?php if($errors->has('image')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('image')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>URL (Link)</label>
                            <input type="url" name="url" class="form-control<?php echo e($errors->has('url') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('url')); ?>" placeholder="Example: https://www.example.com/">
                            <?php if($errors->has('url')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('url')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Status <span class="red">*</span></label> <br>
                            <label><input type="radio" name="status" value="1" class="mr-2" checked required> Active</label>
                            <label class="ml-3"><input type="radio" name="status" value="0" class="mr-2" required> In-Active</label>
                        </div>

                    </div>
                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-outline-info">Upload</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal" id="editSlider<?php echo e($slider->slider_id); ?>">
            <div class="modal-dialog">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Update Images in Slider</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form method="post" action="<?php echo e(route('slider.update', $slider->id)); ?>" enctype="multipart/form-data">
                        <input type="hidden" name="_method" value="PUT">
                    <?php echo e(@csrf_field()); ?>

                    <!-- Modal body -->
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Image Title</label>
                                <input type="text" name="title" class="form-control <?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" value="<?php echo e($slider->title); ?>">
                                <?php if($errors->has('title')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <input type="text" name="description" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" value="<?php echo e($slider->description); ?>">
                                <?php if($errors->has('description')): ?>
                                    <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                                <?php endif; ?>
                            </div>
                            <div class="container">
                                <a href="<?php echo e(asset('images/sliderImage/'.$slider->image)); ?>" data-lightbox="image">
                                    <img src="<?php echo e(asset('images/sliderImage/'.$slider->image)); ?>" height="120px" style="width: 100%; object-fit: scale-down">
                                </a>
                            </div>
                            <div class="form-group">
                                <label>New Image</label>
                                <input type="hidden" name="old_image" value="<?php echo e($slider->image); ?>">
                                <input type="file" name="image" class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>">
                                <?php if($errors->has('image')): ?>
                                    <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('image')); ?></strong>
                            </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>URL (Link)</label>
                                <input type="url" name="url" class="form-control<?php echo e($errors->has('url') ? ' is-invalid' : ''); ?>" value="<?php echo e($slider->url); ?>" placeholder="Example: https://www.example.com/">
                                <?php if($errors->has('url')): ?>
                                    <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('url')); ?></strong>
                            </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Status <span class="red">*</span></label> <br>
                                <label><input type="radio" name="status" value="1" <?php if($slider->status == 1): ?>checked <?php endif; ?> required> Active</label>
                                <label style="margin-left: 20px;"><input type="radio" name="status" value="0" <?php if($slider->status == 0): ?>checked <?php endif; ?> required> In-Active</label>
                            </div>
                        </div>
                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-outline-info">Update</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.includes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Projects\engineering-firm\resources\views/backend/slider/index.blade.php ENDPATH**/ ?>