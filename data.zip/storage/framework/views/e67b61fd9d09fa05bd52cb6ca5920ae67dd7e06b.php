<?php echo $__env->make('backend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('backend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    <?php echo $__env->yieldContent('style'); ?>
</style>

<div class="content-wrapper text-sm">
    <section class="content-header">
        <h1>
            <?php echo $__env->yieldContent('formHeader'); ?>
            <small><?php echo $__env->yieldContent('formSubHeader'); ?></small>
        </h1>

        <br>
        <?php if(session('success_msg')): ?>
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fa fa-check"></i> Success!</h5>
                <?php echo e(session('success_msg')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error_msg')): ?>
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fa fa-ban"></i> Error</h5>
                <?php echo e(session('error_msg')); ?>

            </div>
        <?php endif; ?>

        <?php if(count($errors)>0): ?>
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fa fa-ban"></i> Error</h5>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </section>

    <section class="content">
        <div class="box box-primary">
            <div class="box-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </section>

</div>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<script>
    <?php echo $__env->yieldContent('script'); ?>
</script>

<?php echo $__env->make('backend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Laravel Projects\engineering-firm\resources\views/backend/includes/layout.blade.php ENDPATH**/ ?>