<?php

namespace App\Model\Review;

use Illuminate\Database\Eloquent\Model;

class ServiceReview extends Model
{
    //
}
