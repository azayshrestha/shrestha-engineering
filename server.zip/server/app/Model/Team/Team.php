<?php

namespace App\Model\Team;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    //
}
