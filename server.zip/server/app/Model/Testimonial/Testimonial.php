<?php

namespace App\Model\Testimonial;

use Illuminate\Database\Eloquent\Model;

class Testimonial extends Model
{
    //
}
