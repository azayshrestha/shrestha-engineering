<h5>Subject: {{$data['subject']}}</h5>
<p>{{$data['message']}}</p>

<p>
    Message From: {{$data['name']}},<br>
    Email:{{$data['from']}}
</p>